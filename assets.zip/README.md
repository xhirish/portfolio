# My Portfolio Website


[![Netlify Status](https://api.netlify.com/api/v1/badges/9ba5dafd-e33e-4b76-8d58-a1bfb4b8ad28/deploy-status)](https://app.netlify.com/sites/onkar-shaligram/deploys)

Do tell me if you think that I should add something to my Portfolio.
You are free to clone, fork my repo but don't foget to give credits😁😀

If you wish, You can donte me at https://pages.razorpay.com/pl_EffHr7eq0RB0xN/view


